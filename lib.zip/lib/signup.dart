import 'package:flutter/material.dart';
import 'package:information/login.dart';

class SignUP extends StatefulWidget {
  SignUP({super.key});

  @override
  State<SignUP> createState() => _SignUPState();
}

class _SignUPState extends State<SignUP> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: null,
        body: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 50,
                  margin: EdgeInsets.only(top: 20, bottom: 20),
                  child: Center(
                    child: Text(
                      "Sign Up",
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w600,
                          color: Colors.black),
                    ),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 60,
                  margin: EdgeInsets.only(top: 10),
                  child: Card(
                    child: TextField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(), labelText: "Nama")),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 60,
                  margin: EdgeInsets.only(top: 10),
                  child: Card(
                    child: TextField(
                        decoration: InputDecoration(
                            border: OutlineInputBorder(), labelText: "Email")),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 60,
                  margin: EdgeInsets.only(top: 10),
                  child: Card(
                    child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(), labelText: "Password")),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 50,
                  margin: EdgeInsets.only(top: 20),
                  child: Builder(
                    builder: (context) {
                      return FloatingActionButton.extended(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (context) {
                                return LoginPage();
                              },
                            ));
                          },
                          backgroundColor: Color.fromRGBO(93, 176, 117, 1),
                          label: Center(
                            child: Text(
                              "Sign Up Now",
                              style: TextStyle(fontSize: 20),
                            ),
                          ));
                    },
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Builder(builder: (context) {
                  return TextButton(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return LoginPage();
                      },
                    )),
                    child: Text(
                      "Already have account ?",
                      style: TextStyle(
                          color: Colors.green, fontSize: 15, height: 1.5),
                    ),
                  );
                })
              ],
            )
          ],
        ),
      ),
    );
  }
}
