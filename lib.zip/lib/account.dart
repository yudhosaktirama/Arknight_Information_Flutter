import 'package:flutter/material.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Account Information'),
        ),
        body: MenuAccount(),
      ),
    );
  }
}

class MenuAccount extends StatelessWidget {
  const MenuAccount({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 245,
              height: 50,
              margin: EdgeInsets.only(top: 30),
              child: Card(
                  color: Color.fromRGBO(1, 5, 54, 1),
                  child: Center(
                    child: Text(
                      "Account Information",
                      style: TextStyle(fontSize: 25, color: Colors.white),
                    ),
                  )),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 340,
              height: 400,
              margin: EdgeInsets.only(top: 20),
              color: Color.fromRGBO(1, 5, 54, 1),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          margin: EdgeInsets.all(5),
                          child: Center(
                            child: Text(
                              "Profile",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                  fontWeight: FontWeight.w500),
                            ),
                          ))
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 100,
                        height: 100,
                        margin: EdgeInsets.only(top: 10),
                        child: CircleAvatar(
                          backgroundColor: Colors.white,
                          backgroundImage:
                              AssetImage('assets/images/yudho.jpg'),
                        ),
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          Container(
                            width: 240,
                            height: 50,
                            margin: EdgeInsets.only(top: 20),
                            child: Center(
                              child: Text(
                                "Yudho Sakti Rama S.A",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                          Divider(),
                          Container(
                            width: 270,
                            height: 150,
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 30,
                                      height: 30,
                                      color: Colors.white,
                                      child: Icon(
                                        Icons.account_box,
                                        size: 30,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.all(8),
                                      width: 220,
                                      height: 45,
                                      child: Card(
                                        child: Center(
                                          child: Text(
                                            "yuxxxxxxxx@gmail.com",
                                            style:
                                                TextStyle(color: Colors.black),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 30,
                                      height: 30,
                                      color: Colors.white,
                                      child: Icon(
                                        Icons.password,
                                        size: 25,
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.all(8),
                                      width: 220,
                                      height: 45,
                                      child: Card(
                                        child: Center(
                                          child: Text(
                                            "************",
                                            style:
                                                TextStyle(color: Colors.black),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          )
                        ],
                      )
                    ],
                  )
                ],
              ),
            )
          ],
        )
      ],
    );
  }
}
