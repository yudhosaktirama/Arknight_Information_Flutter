import 'package:flutter/material.dart';
import 'package:information/account.dart';
// ignore: unused_import
import 'package:information/main.dart';

late var gambarClass;

class Home extends StatefulWidget {
  Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final double itemHeight = 150;

  List<Image> gambarClass = [
    Image.asset('assets/images/guard.png', fit: BoxFit.fill),
    Image.asset('assets/images/medic.png', fit: BoxFit.fill),
    Image.asset('assets/images/sniper.png', fit: BoxFit.fill),
    Image.asset(
      'assets/images/specialist.png',
      fit: BoxFit.fill,
    ),
    Image.asset('assets/images/supporter.png', fit: BoxFit.fill),
    Image.asset(
      'assets/images/vanguard.png',
      fit: BoxFit.fill,
    ),
    Image.asset(
      'assets/images/caster.png',
      fit: BoxFit.fill,
    ),
  ];
  List<Text> ClassOperator = [
    Text(
      "Guard",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Medic",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Sniper",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Specialist",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Supporter",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Vanguard",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
    Text(
      "Caster",
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
    ),
  ];
  List<Image> gambarEvent = [
    Image.asset('assets/images/event_fiammeta.png', fit: BoxFit.fill),
    Image.asset('assets/images/event_gnosis.png', fit: BoxFit.fill),
    Image.asset('assets/images/event_near.png', fit: BoxFit.fill),
    Image.asset('assets/images/evet_dusk.png', fit: BoxFit.fill),
  ];
  final List<DataBanner> databaseBanner = [
    DataBanner(
        NamaBanner: 'To Bloom From A Dim Flame',
        tanggalBanner: '2022-12-15',
        gambarBanner: 'assets/images/banner/red_banner.png'),
    DataBanner(
        NamaBanner: 'New Year Banner',
        tanggalBanner: '2023-01-01',
        gambarBanner: 'assets/images/banner/newyear_banner.png'),
    DataBanner(
        NamaBanner: 'Solitude Universal',
        tanggalBanner: '2023-02-14',
        gambarBanner: 'assets/images/banner/chongyue_banner.png'),
    DataBanner(
        NamaBanner: 'Springtide Snowfall',
        tanggalBanner: '2022-12-15',
        gambarBanner: 'assets/images/banner/qiubai_banner.png'),
    DataBanner(
        NamaBanner: 'Flame of Immaculacy Rerun',
        tanggalBanner: '2023-02-21',
        gambarBanner: 'assets/images/banner/fiammeta_banner.png'),
    DataBanner(
        NamaBanner: 'Sharpened by Flame',
        tanggalBanner: '2023-03-07',
        gambarBanner: 'assets/images/banner/yato_banner.png'),
    DataBanner(
        NamaBanner: 'Join Operation 9',
        tanggalBanner: '2023-03-21',
        gambarBanner: 'assets/images/banner/cc12_banner.png'),
    DataBanner(
        NamaBanner: 'The Front That Was 2',
        tanggalBanner: '2023-03-23',
        gambarBanner: 'assets/images/banner/special_banner.png'),
    DataBanner(
        NamaBanner: 'As in My Adumbration',
        tanggalBanner: '2023-04-06',
        gambarBanner: 'assets/images/banner/ines_banner.png'),
    DataBanner(
        NamaBanner: 'Here I Stand',
        tanggalBanner: '2023-05-01',
        gambarBanner: 'assets/images/banner/mulyese_banner.png'),
    DataBanner(
        NamaBanner: 'Join Operation 10',
        tanggalBanner: '2023-05-22',
        gambarBanner: 'assets/images/banner/jo10_banner.png'),
    DataBanner(
        NamaBanner: 'Arbiter ae Quissimus',
        tanggalBanner: '2023-06-08',
        gambarBanner: 'assets/images/banner/executor_banner.png'),
    DataBanner(
        NamaBanner: 'Dissonanzen Rerun',
        tanggalBanner: '2023-06-20',
        gambarBanner: 'assets/images/banner/eben_banner.png'),
  ];
  final List<DataOperator> databaseOperator = [
    DataOperator(Nama: 'kaltsit', Gammbar: 'assets/images/kaltsit.png'),
    DataOperator(Nama: 'Lin Yusha', Gammbar: 'assets/images/lin.png'),
    DataOperator(Nama: 'Red Alter', Gammbar: 'assets/images/red.png'),
    DataOperator(Nama: 'Skadi', Gammbar: 'assets/images/skadi.png'),
    DataOperator(Nama: 'Texas Alter', Gammbar: 'assets/images/texas.png'),
    DataOperator(Nama: 'Vigil', Gammbar: 'assets/images/vigil.png'),
  ];

  List<Map<String, dynamic>> Operator = [
    {
      'Nama': 'Kaltsit',
      'Gambar': 'assets/images/kaltsit.png',
    },
    {
      'Nama': 'Lin Yusha',
      'Gambar': 'assets/images/lin.png',
    },
    {
      'Nama': 'Red Alter',
      'Gambar': 'assets/images/red.png',
    },
    {
      'Nama': 'Skadi',
      'Gambar': 'assets/images/skadi.png',
    },
    {
      'Nama': 'Texas Alter',
      'Gambar': 'assets/images/texas.png',
    },
    {
      'Nama': 'Vigil',
      'Gambar': 'assets/images/vigil.png',
    },
  ];

  var featureOperator = {
    'Nama': [
      'Kaltsit',
      'Lin Yusha',
      'Red Alter',
      'Skadi',
      'Texas Alter',
      'Vigil'
    ],
    'Gambar': [
      Image.asset('assets/images/kaltsit.png', fit: BoxFit.fill),
      Image.asset('assets/images/lin.png', fit: BoxFit.fill),
      Image.asset('assets/images/red.png', fit: BoxFit.fill),
      Image.asset('assets/images/skadi.png', fit: BoxFit.fill),
      Image.asset('assets/images/texas.png', fit: BoxFit.fill),
      Image.asset('assets/images/vigil.png', fit: BoxFit.fill),
    ]
  };

  List<DataEvent> databaseEvent = [
    DataEvent(
        NamaEvent: 'What the Firelight Casts',
        tanggalEvent: '2022-12-15',
        gambarEvent: 'assets/images/event/red_event.png'),
    DataEvent(
        NamaEvent: 'New Year 2023',
        tanggalEvent: '2022-12-24',
        gambarEvent: 'assets/images/event/newyear_event.png'),
    DataEvent(
        NamaEvent: 'Invitation To Wine Rerun',
        tanggalEvent: '2023-01-01',
        gambarEvent: 'assets/images/event/ling_event.png'),
    DataEvent(
        NamaEvent: 'Trials For Navigator',
        tanggalEvent: '2023-01-10',
        gambarEvent: 'assets/images/event/naviTrial_event.png'),
    DataEvent(
        NamaEvent: 'Where Vernal Winds',
        tanggalEvent: '2023-01-17',
        gambarEvent: 'assets/images/event/chongyue_event.png'),
    DataEvent(
        NamaEvent: 'Fire Within The Sand',
        tanggalEvent: '2023-01-29',
        gambarEvent: 'assets/images/event/potamus_event.png'),
    DataEvent(
        NamaEvent: 'A Death in Chunfen',
        tanggalEvent: '2023-02-14',
        gambarEvent: 'assets/images/event/qiubai_event.png'),
    DataEvent(
        NamaEvent: 'Guide Ahead Rerun',
        tanggalEvent: '2023-02-21',
        gambarEvent: 'assets/images/event/fiammeta_event.png'),
    DataEvent(
        NamaEvent: 'Monster Hunter Collab',
        tanggalEvent: '2023-03-07',
        gambarEvent: 'assets/images/event/yato_event.png'),
    DataEvent(
        NamaEvent: 'CC 12 Operation Basepoint',
        tanggalEvent: '2023-03-21',
        gambarEvent: 'assets/images/event/cc12_event.png'),
    DataEvent(
        NamaEvent: 'Episode 12 Preview',
        tanggalEvent: '2023-03-23',
        gambarEvent: 'assets/images/event/ep12Preview_event.png'),
    DataEvent(
        NamaEvent: 'All Quiet Under The Thunder',
        tanggalEvent: '2023-04-06',
        gambarEvent: 'assets/images/event/ines_event.png'),
    DataEvent(
        NamaEvent: 'Stultifera Navis Rerun',
        tanggalEvent: '2023-04-20',
        gambarEvent: 'assets/images/event/irene_event.png'),
    DataEvent(
        NamaEvent: 'Lone Trail',
        tanggalEvent: '2023-05-01',
        gambarEvent: 'assets/images/event/mulyese_event.png'),
    DataEvent(
        NamaEvent: 'Pinch Out Test',
        tanggalEvent: '2023-05-18',
        gambarEvent: 'assets/images/event/pinch_event.png'),
    DataEvent(
        NamaEvent: 'Hortus De Escapismo',
        tanggalEvent: '2023-06-08',
        gambarEvent: 'assets/images/event/executor_event.png'),
    DataEvent(
        NamaEvent: 'Lingering Echoes Rerun',
        tanggalEvent: '2023-06-20',
        gambarEvent: 'assets/images/event/eben_event.png'),
  ];

  int currentIndexcuy = 0;
  String currentMenu = 'Home';

  List<Widget> Menu = [
    MenuHome(
      databaseEvent: [
        DataEvent(
            NamaEvent: 'What the Firelight Casts',
            tanggalEvent: '2022-12-15',
            gambarEvent: 'assets/images/event/red_event.png'),
        DataEvent(
            NamaEvent: 'New Year 2023',
            tanggalEvent: '2022-12-24',
            gambarEvent: 'assets/images/event/newyear_event.png'),
        DataEvent(
            NamaEvent: 'Invitation To Wine Rerun',
            tanggalEvent: '2023-01-01',
            gambarEvent: 'assets/images/event/ling_event.png'),
        DataEvent(
            NamaEvent: 'Trials For Navigator',
            tanggalEvent: '2023-01-10',
            gambarEvent: 'assets/images/event/naviTrial_event.png'),
        DataEvent(
            NamaEvent: 'Where Vernal Winds',
            tanggalEvent: '2023-01-17',
            gambarEvent: 'assets/images/event/chongyue_event.png'),
        DataEvent(
            NamaEvent: 'Fire Within The Sand',
            tanggalEvent: '2023-01-29',
            gambarEvent: 'assets/images/event/potamus_event.png'),
        DataEvent(
            NamaEvent: 'A Death in Chunfen',
            tanggalEvent: '2023-02-14',
            gambarEvent: 'assets/images/event/qiubai_event.png'),
        DataEvent(
            NamaEvent: 'Guide Ahead Rerun',
            tanggalEvent: '2023-02-21',
            gambarEvent: 'assets/images/event/fiammeta_event.png'),
        DataEvent(
            NamaEvent: 'Monster Hunter Collab',
            tanggalEvent: '2023-03-07',
            gambarEvent: 'assets/images/event/yato_event.png'),
        DataEvent(
            NamaEvent: 'CC 12 Operation Basepoint',
            tanggalEvent: '2023-03-21',
            gambarEvent: 'assets/images/event/cc12_event.png'),
        DataEvent(
            NamaEvent: 'Episode 12 Preview',
            tanggalEvent: '2023-03-23',
            gambarEvent: 'assets/images/event/ep12Preview_event.png'),
        DataEvent(
            NamaEvent: 'All Quiet Under The Thunder',
            tanggalEvent: '2023-04-06',
            gambarEvent: 'assets/images/event/ines_event.png'),
        DataEvent(
            NamaEvent: 'Stultifera Navis Rerun',
            tanggalEvent: '2023-04-20',
            gambarEvent: 'assets/images/event/irene_event.png'),
        DataEvent(
            NamaEvent: 'Lone Trail',
            tanggalEvent: '2023-05-01',
            gambarEvent: 'assets/images/event/mulyese_event.png'),
        DataEvent(
            NamaEvent: 'Pinch Out Test',
            tanggalEvent: '2023-05-18',
            gambarEvent: 'assets/images/event/pinch_event.png'),
        DataEvent(
            NamaEvent: 'Hortus De Escapismo',
            tanggalEvent: '2023-06-08',
            gambarEvent: 'assets/images/event/executor_event.png'),
        DataEvent(
            NamaEvent: 'Lingering Echoes Rerun',
            tanggalEvent: '2023-06-20',
            gambarEvent: 'assets/images/event/eben_event.png'),
      ],
      databaseBanner: [
        DataBanner(
            NamaBanner: 'To Bloom From A Dim Flame',
            tanggalBanner: '2022-12-15',
            gambarBanner: 'assets/images/banner/red_banner.png'),
        DataBanner(
            NamaBanner: 'New Year Banner',
            tanggalBanner: '2023-01-01',
            gambarBanner: 'assets/images/banner/newyear_banner.png'),
        DataBanner(
            NamaBanner: 'Solitude Universal',
            tanggalBanner: '2023-02-14',
            gambarBanner: 'assets/images/banner/chongyue_banner.png'),
        DataBanner(
            NamaBanner: 'Springtide Snowfall',
            tanggalBanner: '2022-12-15',
            gambarBanner: 'assets/images/banner/qiubai_banner.png'),
        DataBanner(
            NamaBanner: 'Flame of Immaculacy Rerun',
            tanggalBanner: '2023-02-21',
            gambarBanner: 'assets/images/banner/fiammeta_banner.png'),
        DataBanner(
            NamaBanner: 'Sharpened by Flame',
            tanggalBanner: '2023-03-07',
            gambarBanner: 'assets/images/banner/yato_banner.png'),
        DataBanner(
            NamaBanner: 'Join Operation 9',
            tanggalBanner: '2023-03-21',
            gambarBanner: 'assets/images/banner/cc12_banner.png'),
        DataBanner(
            NamaBanner: 'The Front That Was 2',
            tanggalBanner: '2023-03-23',
            gambarBanner: 'assets/images/banner/special_banner.png'),
        DataBanner(
            NamaBanner: 'As in My Adumbration',
            tanggalBanner: '2023-04-06',
            gambarBanner: 'assets/images/banner/ines_banner.png'),
        DataBanner(
            NamaBanner: 'Here I Stand',
            tanggalBanner: '2023-05-01',
            gambarBanner: 'assets/images/banner/mulyese_banner.png'),
        DataBanner(
            NamaBanner: 'Join Operation 10',
            tanggalBanner: '2023-05-22',
            gambarBanner: 'assets/images/banner/jo10_banner.png'),
        DataBanner(
            NamaBanner: 'Arbiter ae Quissimus',
            tanggalBanner: '2023-06-08',
            gambarBanner: 'assets/images/banner/executor_banner.png'),
        DataBanner(
            NamaBanner: 'Dissonanzen Rerun',
            tanggalBanner: '2023-06-20',
            gambarBanner: 'assets/images/banner/eben_banner.png'),
      ],
      databaseOperator: [
        DataOperator(Nama: 'kaltsit', Gammbar: 'assets/images/kaltsit.png'),
        DataOperator(Nama: 'Lin Yusha', Gammbar: 'assets/images/lin.png'),
        DataOperator(Nama: 'Red Alter', Gammbar: 'assets/images/red.png'),
        DataOperator(Nama: 'Skadi', Gammbar: 'assets/images/skadi.png'),
        DataOperator(Nama: 'Texas Alter', Gammbar: 'assets/images/texas.png'),
        DataOperator(Nama: 'Vigil', Gammbar: 'assets/images/vigil.png'),
      ],
      gambarClass: [
        Image.asset('assets/images/guard.png', fit: BoxFit.fill),
        Image.asset('assets/images/medic.png', fit: BoxFit.fill),
        Image.asset('assets/images/sniper.png', fit: BoxFit.fill),
        Image.asset(
          'assets/images/specialist.png',
          fit: BoxFit.fill,
        ),
        Image.asset('assets/images/supporter.png', fit: BoxFit.fill),
        Image.asset(
          'assets/images/vanguard.png',
          fit: BoxFit.fill,
        ),
        Image.asset(
          'assets/images/caster.png',
          fit: BoxFit.fill,
        ),
        Image.asset(
          'assets/images/defender.png',
          fit: BoxFit.fill,
        ),
      ],
      ClassOperator: [
        Text(
          "Guard",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Medic",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Sniper",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Specialist",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Supporter",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Vanguard",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Caster",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        Text(
          "Defender",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
      ],
      featureOperatorJadi: [
        DataFeatureOperator(
            NamaOpeator: "Vigil",
            IconSkill1: 'assets/images/test/cobaskill.png',
            judulSkill1: "Packleader's Call",
            IconSklii2: 'assets/images/Skill/vigil_skill2.png',
            judulSkill2: "Packleader's Gift",
            IconSkill3: 'assets/images/Skill/vigil_skill3.png',
            judulSkill3: ": Packleader's Dignity",
            IconArchytype: 'assets/images/Archytype/virgil_archy.png',
            IconClass: 'assets/images/vanguard.png',
            Gambar: 'assets/images/test/contoh.png'),
        DataFeatureOperator(
            NamaOpeator: "Ebenholz",
            IconSkill1: 'assets/images/Skill/eben_skill1.png',
            judulSkill1: "Quickening Presto",
            IconSklii2: 'assets/images/Skill/eben_skill2.png',
            judulSkill2: "Desolate Echoes",
            IconSkill3: 'assets/images/Skill/eben_skill3.png',
            judulSkill3: "Sound of Silence",
            IconArchytype: 'assets/images/Archytype/eben_archy.png',
            IconClass: 'assets/images/caster.png',
            Gambar: 'assets/images/Model/eben_model.png'),
        DataFeatureOperator(
            NamaOpeator: "Texas the Omertosa",
            IconSkill1: 'assets/images/Skill/texas_skill1.png',
            judulSkill1: "Silent Drizzle",
            IconSklii2: 'assets/images/Skill/texas_skill2.png',
            judulSkill2: "Unrelenting Downpour",
            IconSkill3: 'assets/images/Skill/texas_skill3.png',
            judulSkill3: "Torrential Sword Rain",
            IconArchytype: 'assets/images/Archytype/texas_archy.png',
            IconClass: 'assets/images/specialist.png',
            Gambar: 'assets/images/Model/texas_model.png'),
        DataFeatureOperator(
            NamaOpeator: "Kal'tsit",
            IconSkill1: 'assets/images/Skill/kaltsit_skill1.png',
            judulSkill1: "Command: Structural Fortification",
            IconSklii2: 'assets/images/Skill/kaltsit_skill2.png',
            judulSkill2: "Command: Tactical Coordination",
            IconSkill3: 'assets/images/Skill/kaltsit_skill3.png',
            judulSkill3: "Command: Meltdown",
            IconArchytype: 'assets/images/Archytype/kaltsit_archy.png',
            IconClass: 'assets/images/medic.png',
            Gambar: 'assets/images/Model/kaltsit_model.png'),
        DataFeatureOperator(
            NamaOpeator: "Młynar",
            IconSkill1: 'assets/images/Skill/mylnar_skill1.png',
            judulSkill1: "Unvoiced Anger",
            IconSklii2: 'assets/images/Skill/mylnar_skill2.png',
            judulSkill2: "Unresolved Sorrow",
            IconSkill3: 'assets/images/Skill/mylnar_skill3.png',
            judulSkill3: "Unbrilliant Glory",
            IconArchytype: 'assets/images/Archytype/mylnar_archy.png',
            IconClass: 'assets/images/guard.png',
            Gambar: 'assets/images/Model/mylnar_model.png'),
        DataFeatureOperator(
            NamaOpeator: "Penance",
            IconSkill1: 'assets/images/Skill/penance_skill1.png',
            judulSkill1: "Last Word",
            IconSklii2: 'assets/images/Skill/penance_skill2.png',
            judulSkill2: "Stoic Atonement",
            IconSkill3: 'assets/images/Skill/penance_skill3.png',
            judulSkill3: "Trial of Thorns",
            IconArchytype: 'assets/images/Archytype/penance_archy.png',
            IconClass: 'assets/images/defender.png',
            Gambar: 'assets/images/Model/penance_model.png'),
      ],
    ),
    MenuAccount()
  ];

  final List<DataFeatureOperator> featureOperatorJadi = [
    DataFeatureOperator(
        NamaOpeator: "Vigil",
        IconSkill1: 'assets/images/test/cobaskill.png',
        judulSkill1: "judulSkill1",
        IconSklii2: 'assets/images/test/cobaskill.png',
        judulSkill2: 'judulSkill2',
        IconSkill3: 'assets/images/test/cobaskill.png',
        judulSkill3: 'judulSkill3',
        IconArchytype: 'assets/images/test/cobaskill.png',
        IconClass: 'assets/images/test/cobaskill.png',
        Gambar: 'assets/images/test/contoh.png'),
    DataFeatureOperator(
        NamaOpeator: "Asep",
        IconSkill1: 'assets/images/test/cobaskill.png',
        judulSkill1: "judulSkill1",
        IconSklii2: 'assets/images/test/cobaskill.png',
        judulSkill2: 'judulSkill2',
        IconSkill3: 'assets/images/test/cobaskill.png',
        judulSkill3: 'judulSkill3',
        IconArchytype: 'assets/images/test/cobaskill.png',
        IconClass: 'assets/images/test/cobaskill.png',
        Gambar: 'assets/images/test/contoh.png'),
    DataFeatureOperator(
        NamaOpeator: "Cuyy",
        IconSkill1: 'assets/images/test/cobaskill.png',
        judulSkill1: "judulSkill1",
        IconSklii2: 'assets/images/test/cobaskill.png',
        judulSkill2: 'judulSkill2',
        IconSkill3: 'assets/images/test/cobaskill.png',
        judulSkill3: 'judulSkill3',
        IconArchytype: 'assets/images/test/cobaskill.png',
        IconClass: 'assets/images/test/cobaskill.png',
        Gambar: 'assets/images/test/contoh.png'),
  ];

  void pindahMenu(int Index) {
    setState(() {
      if (Index == 0) {
        currentIndexcuy = Index;
        currentMenu = 'Home';
      } else if (Index == 1) {
        currentIndexcuy = Index;
        currentMenu = 'Account';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color.fromRGBO(158, 210, 232, 0.69),
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(1, 5, 54, 1),
          title: Center(
            child: Text("Arknight Information"),
          ),
        ),
        body: Menu[currentIndexcuy],
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Color.fromRGBO(1, 5, 54, 1),

          //membuat item navigasi
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Account'),
          ],

          //currentindex mengikuti baris item bottom navigasi yang diklik

          //warna saat item diklik
          currentIndex: currentIndexcuy,
          selectedItemColor: Colors.blue,
          unselectedItemColor: Colors.white,
          onTap: pindahMenu,

          //metode yang dijalankan saat ditap

          //agar bottom navigation tidak bergerak saat diklik
          type: BottomNavigationBarType.fixed,
        ),
      ),
    );
  }
}

class MenuHome extends StatefulWidget {
  const MenuHome({
    super.key,
    required this.databaseEvent,
    required this.databaseBanner,
    required this.databaseOperator,
    required this.gambarClass,
    required this.ClassOperator,
    required this.featureOperatorJadi,
  });

  final List<DataEvent> databaseEvent;
  final List<DataBanner> databaseBanner;
  final List<DataOperator> databaseOperator;
  final List<Image> gambarClass;
  final List<Text> ClassOperator;
  final List<DataFeatureOperator> featureOperatorJadi;

  @override
  State<MenuHome> createState() => _MenuHomeState();
}

class _MenuHomeState extends State<MenuHome> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Column(
        children: [
          Welcome(),
          TextEvent(),
          EventWidget(databaseEvent: widget.databaseEvent),
          TextBanner(),
          BannerWidget(databaseBanner: widget.databaseBanner),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  margin: EdgeInsets.all(5),
                  child: Card(
                    color: Color.fromRGBO(10, 24, 31, 0.82),
                    child: Text(
                      "Feature Operator",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                          color: Colors.white),
                    ),
                  ))
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 380,
                height: 374,
                color: Color.fromRGBO(10, 24, 31, 0.82),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: widget.featureOperatorJadi.map((data) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 380,
                                  height: 50,
                                  margin: EdgeInsets.only(right: 10),
                                  color: Color.fromRGBO(1, 5, 54, 1),
                                  child: Center(
                                    child: Text(
                                      'Operator Name : ${data.NamaOpeator}',
                                      style: TextStyle(
                                          fontSize: 20, color: Colors.white),
                                    ),
                                  ),
                                )
                              ],
                            ),
                            Divider(),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.all(4),
                                      width: 128,
                                      height: 218,
                                      color: Color.fromRGBO(1, 5, 54, 1),
                                      child: Image.asset(
                                        data.Gambar,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.all(4),
                                      width: 240,
                                      height: 219,
                                      color: Color.fromRGBO(1, 5, 54, 1),
                                      child: Column(
                                        children: [
                                          Container(
                                            width: 200,
                                            height: 60,
                                            margin: EdgeInsets.all(6),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 3),
                                                  color: Colors.black,
                                                  child: Image.asset(
                                                    data.IconSkill1,
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Container(
                                                  width: 160,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 5),
                                                  color: Colors.white,
                                                  child: Center(
                                                    child:
                                                        SingleChildScrollView(
                                                            scrollDirection:
                                                                Axis.horizontal,
                                                            child: Container(
                                                              margin: EdgeInsets
                                                                  .all(3),
                                                              child: Text(
                                                                  "Skill 1 : ${data.judulSkill1}"),
                                                            )),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 200,
                                            height: 60,
                                            margin: EdgeInsets.all(6),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 3),
                                                  color: Colors.black,
                                                  child: Image.asset(
                                                    data.IconSklii2,
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Container(
                                                  width: 160,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 5),
                                                  color: Colors.white,
                                                  child: Center(
                                                    child: SingleChildScrollView(
                                                        scrollDirection:
                                                            Axis.horizontal,
                                                        child: Container(
                                                          margin: EdgeInsets.all(3),
                                                          child: Text(
                                                              "Skill 2 : ${data.judulSkill2}"),
                                                        )),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            width: 200,
                                            height: 60,
                                            margin: EdgeInsets.all(6),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 30,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 3),
                                                  color: Colors.black,
                                                  child: Image.asset(
                                                    data.IconSkill3,
                                                    fit: BoxFit.fill,
                                                  ),
                                                ),
                                                Container(
                                                  width: 160,
                                                  height: 40,
                                                  margin:
                                                      EdgeInsets.only(left: 5),
                                                  color: Colors.white,
                                                  child: Center(
                                                    child: SingleChildScrollView(
                                                        scrollDirection:
                                                            Axis.horizontal,
                                                        child: Container(
                                                          margin: EdgeInsets.all(3),
                                                          child: Text(
                                                              "Skill 3 : ${data.judulSkill3}"),
                                                        )),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  width: 280,
                                  height: 58,
                                  margin: EdgeInsets.all(8),
                                  color: Color.fromRGBO(1, 5, 54, 1),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 52,
                                        height: 40,
                                        margin: EdgeInsets.only(right: 4),
                                        color: Colors.black,
                                        child: Card(
                                          color: Colors.black,
                                          child: Center(
                                              child: Text(
                                            "Class : ",
                                            style:
                                                TextStyle(color: Colors.white),
                                          )),
                                        ),
                                      ),
                                      Container(
                                        width: 52,
                                        height: 40,
                                        color: Colors.black,
                                        margin: EdgeInsets.only(right: 9),
                                        child: Image.asset(
                                          data.IconClass,
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      Container(
                                        width: 78,
                                        height: 40,
                                        color: Colors.black,
                                        child: Card(
                                          color: Colors.black,
                                          child: Center(
                                              child: Text(
                                            "Archytype : ",
                                            style:
                                                TextStyle(color: Colors.white),
                                          )),
                                        ),
                                      ),
                                      Container(
                                        width: 52,
                                        height: 40,
                                        color: Colors.black,
                                        margin: EdgeInsets.only(left: 3),
                                        child: Image.asset(
                                          data.IconArchytype,
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ],
                    );
                  }).toList(growable: true),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                  margin: EdgeInsets.all(5),
                  child: Card(
                    color: Color.fromRGBO(10, 24, 31, 0.82),
                    child: Text(
                      "Operator Class",
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ))
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 380,
                height: 300,
                child: GridView.builder(
                  itemCount: widget.gambarClass.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3, childAspectRatio: 200 / 250),
                  itemBuilder: (context, index) {
                    return Card(
                      child: Container(
                          width: 380,
                          height: 180,
                          color: Colors.black,
                          margin: EdgeInsets.all(10),
                          child: Column(
                            children: [
                              Container(
                                width: 200,
                                height: 20,
                                color: Colors.lightBlue,
                                child: Center(
                                  child: widget.ClassOperator[index],
                                ),
                              ),
                              Container(
                                child: widget.gambarClass[index],
                              )
                            ],
                          )),
                    );
                  },
                ),
              )
            ],
          ),
          Divider(),
        ],
      ),
    );
  }
}

class BannerWidget extends StatefulWidget {
  const BannerWidget({
    super.key,
    required this.databaseBanner,
  });

  final List<DataBanner> databaseBanner;

  @override
  State<BannerWidget> createState() => _BannerWidgetState();
}

class _BannerWidgetState extends State<BannerWidget> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 380,
          height: 220,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: widget.databaseBanner.map((databasebannerarknight) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      Container(
                        width: 280,
                        margin: EdgeInsets.only(right: 10),
                        child: Card(
                          color: Color.fromRGBO(1, 5, 54, 1),
                          child: Center(
                            child: Text(
                              databasebannerarknight.NamaBanner,
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 275,
                        height: 150,
                        margin: EdgeInsets.only(right: 10),
                        child: Image.asset(
                          databasebannerarknight.gambarBanner,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Container(
                        width: 280,
                        margin: EdgeInsets.only(right: 10),
                        child: Card(
                          color: Color.fromRGBO(1, 5, 54, 1),
                          child: Center(
                            child: Text(
                              "Date : ${databasebannerarknight.tanggalBanner}",
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      )
                    ],
                  )
                ],
              );
            }).toList(),
          ),
        )
      ],
    );
  }
}

class TextBanner extends StatefulWidget {
  const TextBanner({
    super.key,
  });

  @override
  State<TextBanner> createState() => _TextBannerState();
}

class _TextBannerState extends State<TextBanner> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          width: 200,
          margin: EdgeInsets.only(top: 10, bottom: 10),
          child: Card(
            color: Color.fromRGBO(10, 24, 31, 0.82),
            child: Center(
              child: Text(
                "Upcoming Banner",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontSize: 20),
              ),
            ),
          ),
        )
      ],
    );
  }
}

class EventWidget extends StatefulWidget {
  const EventWidget({
    super.key,
    required this.databaseEvent,
  });

  final List<DataEvent> databaseEvent;

  @override
  State<EventWidget> createState() => _EventWidgetState();
}

class _EventWidgetState extends State<EventWidget> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 380,
          height: 220,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: widget.databaseEvent.map((dataeventarknight) {
              return Row(
                children: [
                  Column(
                    children: [
                      Container(
                        width: 300,
                        margin: EdgeInsets.only(right: 10),
                        child: Card(
                          color: Color.fromRGBO(1, 5, 54, 1),
                          child: Center(
                            child: Text(
                              dataeventarknight.NamaEvent,
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        margin: EdgeInsets.only(right: 10),
                        child: Image.asset(
                          dataeventarknight.gambarEvent,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Container(
                        width: 300,
                        margin: EdgeInsets.only(right: 10),
                        child: Card(
                          color: Color.fromRGBO(1, 5, 54, 1),
                          child: Center(
                            child: Text(
                              "Date : ${dataeventarknight.tanggalEvent}",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                      )
                    ],
                  )
                ],
              );
            }).toList(),
          ),
        )
      ],
    );
  }
}

class TextEvent extends StatefulWidget {
  const TextEvent({
    super.key,
  });

  @override
  State<TextEvent> createState() => _TextEventState();
}

class _TextEventState extends State<TextEvent> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
            width: 200,
            margin: EdgeInsets.all(5),
            child: Card(
              color: Color.fromRGBO(10, 24, 31, 0.82),
              child: Center(
                child: Text(
                  "Upcoming Event",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      color: Colors.white),
                ),
              ),
            ))
      ],
    );
  }
}

class Welcome extends StatefulWidget {
  const Welcome({
    super.key,
  });

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          width: 350,
          height: 60,
          margin: EdgeInsets.only(
            top: 10,
          ),
          child: Card(
              color: Color.fromRGBO(1, 5, 54, 1),
              child: Center(
                child: Text(
                  "Selamat Datang Yudho",
                  style: TextStyle(fontSize: 25, color: Colors.white),
                ),
              )),
        )
      ],
    );
  }
}

class DataOperator {
  final String Nama;
  final String Gammbar;

  DataOperator({required this.Nama, required this.Gammbar});
}

class DataEvent {
  final String NamaEvent;
  final String tanggalEvent;
  final String gambarEvent;

  DataEvent(
      {required this.NamaEvent,
      required this.tanggalEvent,
      required this.gambarEvent});
}

class DataBanner {
  final String NamaBanner;
  final String tanggalBanner;
  final String gambarBanner;

  DataBanner(
      {required this.NamaBanner,
      required this.tanggalBanner,
      required this.gambarBanner});
}

class DataFeatureOperator {
  final String NamaOpeator;
  final String IconSkill1;
  final String judulSkill1;
  final String IconSklii2;
  final String judulSkill2;
  final String IconSkill3;
  final String judulSkill3;
  final String IconArchytype;
  final String IconClass;
  final String Gambar;

  DataFeatureOperator(
      {required this.NamaOpeator,
      required this.IconSkill1,
      required this.judulSkill1,
      required this.IconSklii2,
      required this.judulSkill2,
      required this.IconSkill3,
      required this.judulSkill3,
      required this.IconArchytype,
      required this.IconClass,
      required this.Gambar});
}
