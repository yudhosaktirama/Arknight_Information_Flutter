import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:information/signup.dart';

class LoginPage extends StatefulWidget {
  LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: null,
        body: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 40),
                  width: 343,
                  height: 80,
                  child: const Center(
                    child: Text(
                      "Log in",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 30,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 60,
                  margin: EdgeInsets.only(top: 20),
                  child: const Card(
                    child: TextField(
                      decoration: InputDecoration(
                          border: OutlineInputBorder(), labelText: "Email"),
                    ),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 60,
                  margin: EdgeInsets.only(top: 20),
                  child: Card(
                    child: TextField(
                        obscureText: true,
                        decoration: InputDecoration(
                            suffixIcon: IconButton(
                                onPressed: () {
                                  TextField(
                                    obscureText: false,
                                  );
                                },
                                icon: Icon(CupertinoIcons.eye)),
                            border: OutlineInputBorder(),
                            labelText: "Password")),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 343,
                  height: 50,
                  margin: EdgeInsets.only(top: 20),
                  child: Builder(builder: (context) {
                    return FloatingActionButton.extended(
                        heroTag: null,
                        onPressed: () {
                          Navigator.pushReplacement(context, MaterialPageRoute(
                            builder: (context) {
                              return SignUP();
                            },
                          ));
                        },
                        backgroundColor: Color.fromRGBO(93, 176, 117, 1),
                        label: Center(
                            child: Text(
                          "Log in",
                          style: TextStyle(fontSize: 25),
                        )));
                  }),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 178,
                  height: 19,
                  margin: EdgeInsets.only(top: 5),
                  child: Center(
                    child: Text(
                      "Forgot your password ?",
                      style: TextStyle(
                        color: Color(0xFF5DB075),
                      ),
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
