import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:information/account.dart';
// ignore: unused_import
import 'package:information/home.dart';
// ignore: unused_import
import 'package:information/login.dart';
// ignore: unused_import
import 'package:information/signup.dart';

void main() {
  runApp(Awal());
}

class Awal extends StatefulWidget {
 Awal({super.key});

  @override
  State<Awal> createState() => _AwalState();
}

class _AwalState extends State<Awal> {
  @override
  Widget build(BuildContext context) {
    return Home();
  }
}
